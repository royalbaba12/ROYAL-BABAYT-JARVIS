ROYAL BABAYT JARVIS - Android WebView project
======================================

इस ZIP में आपकी JARVIS_Hindi_Voice.html को app/src/main/assets/index.html के रूप में रखा गया है।
यह Android Studio का source project है, तैयार APK नहीं।

महत्वपूर्ण:
- इस project को compile करने के लिए Android Studio/Gradle build environment चाहिए।
- Android WebView में Web Speech Recognition (SpeechRecognition / webkitSpeechRecognition) हर डिवाइस पर समर्थित नहीं है।
  इसलिए APK खुल सकता है, लेकिन माइक्रोफ़ोन से बोलकर कमांड देना चलने की गारंटी नहीं है।
- HTML में browser speechSynthesis से हिंदी आवाज़ भी डिवाइस के installed Text-to-Speech engine पर निर्भर है।
- बेहतर voice support के लिए native Android SpeechRecognizer और TextToSpeech bridge जोड़ना होगा, या पेज को HTTPS पर Chrome में चलाना होगा।

Build steps (कंप्यूटर पर):
1. ZIP extract करें।
2. Android Studio में इस folder को Open करें।
3. Gradle sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।

फोन-मात्र उपयोग:
Android Studio मोबाइल पर उपलब्ध नहीं है। मोबाइल से ऑनलाइन builder/IDE इस्तेमाल किया जा सकता है, पर free tier, file import और microphone support अलग-अलग हो सकते हैं। किसी builder को पैसे देने से पहले उसकी free APK export सुविधा जाँचें।


इस संशोधित संस्करण में:
- ऐप का launcher नाम और स्क्रीन ब्रांडिंग ROYAL BABAYT JARVIS की गई है।
- WebView microphone permission request को Android permission result के बाद सही तरह grant/deny करने का सुधार किया गया है।
- यह अभी source project है, तैयार APK नहीं। APK बनाने के लिए Android SDK और Gradle वाला build environment आवश्यक है।
- Voice recognition WebView/Android संस्करण और speech service पर निर्भर है; हर फोन पर इसकी गारंटी नहीं है।
